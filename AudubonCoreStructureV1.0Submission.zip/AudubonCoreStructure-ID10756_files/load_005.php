$(document).ready(function(){});;mw.loader.state({"site":"ready"});
/* cache key: gbif_kos:resourceloader:filter:minify-js:7:cb9f8c7bce10f94eb8dd6cc626fada48 */
/* Cached 20131022235839 */